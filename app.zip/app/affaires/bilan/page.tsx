"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";

type LigneHistorique = {
  annee: number;
  semaine: number;
  collaborateur_id: string;
  affaire_code: string;
  code_imputation: string;
  heures: number;
  trigramme: string;
};

type LigneTableau = {
  semaine: number;
  annee: number;
  trigramme: string;
  codes: Record<string, number>;
  total: number;
};

type Collaborateur = {
  id: string;
  trigramme: string | null;
};

export default function BilanAffairesPage() {
  const router = useRouter();

  const [typeAffaire, setTypeAffaire] = useState("CBE");
  const [numero, setNumero] = useState("");

  const [lignes, setLignes] = useState<LigneHistorique[]>([]);

  const [message, setMessage] = useState("");
  const [chargement, setChargement] = useState(false);

  const [filtreTrigramme, setFiltreTrigramme] =
    useState("");

  const [filtreSemaine, setFiltreSemaine] =
    useState("");

  const [triColonne, setTriColonne] =
    useState<"semaine" | "trigramme" | "total" | string>(
      "semaine"
    );

  const [triDirection, setTriDirection] =
    useState<"asc" | "desc">("asc");

  async function rechercher() {
    if (!numero.trim()) {
      setMessage(
        "Veuillez saisir un numéro d'affaire."
      );
      return;
    }

    setChargement(true);
    setLignes([]);
    setMessage("");

    const affaireRecherchee =
      `${typeAffaire}${numero.trim()}`.toUpperCase();

    /*
     * On retire une éventuelle révision.
     *
     * CBE1449
     * CBE1449R1
     * CBE1449R2
     *
     * seront tous considérés comme CBE1449.
     */
    const affaireMere =
      affaireRecherchee.replace(/R\d+$/i, "");

    /* =====================================================
       1. RÉCUPÉRATION DES IMPUTATIONS
       ===================================================== */

    const {
      data: imputations,
      error: erreurImputations,
    } = await supabase
      .from("historique_imputations")
      .select(
        `
        annee,
        semaine,
        collaborateur_id,
        affaire_code,
        code_imputation,
        heures
        `
      );

    if (erreurImputations) {
      console.error(
        "Erreur récupération historique :",
        erreurImputations
      );

      setMessage(
        "Erreur lors de la récupération de l'historique."
      );

      setChargement(false);
      return;
    }

    /*
     * On filtre uniquement l'affaire recherchée.
     */
    const imputationsAffaire =
      (imputations ?? []).filter((ligne) => {
        const affaire =
          String(ligne.affaire_code ?? "")
            .toUpperCase()
            .trim();

        const mere =
          affaire.replace(/R\d+$/i, "");

        return mere === affaireMere;
      });

    if (imputationsAffaire.length === 0) {
      setMessage(
        `Aucune imputation trouvée pour ${affaireRecherchee}.`
      );

      setChargement(false);
      return;
    }

    /* =====================================================
       2. RÉCUPÉRATION DES COLLABORATEURS
       ===================================================== */

    /*
     * On récupère uniquement les collaborateurs réellement
     * présents dans les imputations.
     */
    const idsCollaborateurs =
      Array.from(
        new Set(
          imputationsAffaire
            .map(
              (ligne) =>
                ligne.collaborateur_id
            )
            .filter(Boolean)
        )
      );

    const {
      data: collaborateurs,
      error: erreurCollaborateurs,
    } = await supabase
      .from("collaborateurs")
      .select(
        `
        id,
        trigramme
        `
      )
      .in(
        "id",
        idsCollaborateurs
      );

    if (erreurCollaborateurs) {
      console.error(
        "Erreur récupération collaborateurs :",
        erreurCollaborateurs
      );

      setMessage(
        "Erreur lors de la récupération des collaborateurs."
      );

      setChargement(false);
      return;
    }

    /* =====================================================
       3. CRÉATION D'UNE MAP ID → TRIGRAMME
       ===================================================== */

    const mapCollaborateurs =
      new Map<string, string>();

    for (
      const collaborateur of
      (collaborateurs ?? []) as Collaborateur[]
    ) {
      mapCollaborateurs.set(
        collaborateur.id,
        collaborateur.trigramme ??
          "???"
      );
    }

    /* =====================================================
       4. CONSTRUCTION DES LIGNES
       ===================================================== */

    const resultat: LigneHistorique[] =
      imputationsAffaire.map(
        (ligne) => ({
          annee: Number(
            ligne.annee ?? 0
          ),

          semaine: Number(
            ligne.semaine ?? 0
          ),

          collaborateur_id:
            String(
              ligne.collaborateur_id ??
                ""
            ),

          affaire_code:
            String(
              ligne.affaire_code ??
                ""
            ),

          code_imputation:
            String(
              ligne.code_imputation ??
                ""
            ),

          heures: Number(
            ligne.heures ?? 0
          ),

          trigramme:
            mapCollaborateurs.get(
              String(
                ligne.collaborateur_id ??
                  ""
              )
            ) ?? "???",
        })
      );

    setLignes(resultat);

    setMessage(
      `${resultat.length} imputation${
        resultat.length > 1
          ? "s"
          : ""
      } trouvée${
        resultat.length > 1
          ? "s"
          : ""
      }.`
    );

    setChargement(false);
  }

  /* =======================================================
     CODES UTILISÉS
     ======================================================= */

  const codes = useMemo(() => {
    const ensemble =
      new Set<string>();

    for (const ligne of lignes) {
      const code =
        ligne.code_imputation.trim();

      if (code) {
        ensemble.add(code);
      }
    }

    return Array.from(
      ensemble
    ).sort();
  }, [lignes]);

  /* =======================================================
     TOTAL HEURES
     ======================================================= */

  const totalHeures = useMemo(() => {
    return lignes.reduce(
      (total, ligne) =>
        total + ligne.heures,
      0
    );
  }, [lignes]);

  /* =======================================================
     COLLABORATEURS
     ======================================================= */

  const collaborateurs = useMemo(() => {
    return Array.from(
      new Set(
        lignes
          .map(
            (ligne) =>
              ligne.trigramme
          )
          .filter(Boolean)
      )
    ).sort();
  }, [lignes]);

  /* =======================================================
     SEMAINES
     ======================================================= */

  const semaines = useMemo(() => {
    const ensemble =
      new Set<string>();

    for (const ligne of lignes) {
      ensemble.add(
        `${ligne.semaine}-${ligne.annee}`
      );
    }

    return Array.from(
      ensemble
    ).sort((a, b) => {
      const [
        semaineA,
        anneeA,
      ] = a
        .split("-")
        .map(Number);

      const [
        semaineB,
        anneeB,
      ] = b
        .split("-")
        .map(Number);

      return (
        anneeA * 100 +
        semaineA -
        (anneeB * 100 +
          semaineB)
      );
    });
  }, [lignes]);

  /* =======================================================
     CONSTRUCTION DU TABLEAU
     ======================================================= */

  const tableau =
    useMemo<LigneTableau[]>(() => {
      const groupes =
        new Map<
          string,
          LigneTableau
        >();

      for (const ligne of lignes) {
        const trigramme =
          ligne.trigramme ||
          "???";

        /*
         * Une ligne =
         * Semaine + Année + Trigramme
         */
        const cle =
          `${ligne.annee}-${ligne.semaine}-${trigramme}`;

        if (!groupes.has(cle)) {
          groupes.set(cle, {
            semaine:
              ligne.semaine,

            annee:
              ligne.annee,

            trigramme,

            codes: {},

            total: 0,
          });
        }

        const groupe =
          groupes.get(cle)!;

        const code =
          ligne.code_imputation.trim();

        const heures =
          Number(ligne.heures);

        if (code) {
          groupe.codes[code] =
            (groupe.codes[code] ??
              0) + heures;
        }

        groupe.total += heures;
      }

      return Array.from(
        groupes.values()
      );
    }, [lignes]);

  /* =======================================================
     FILTRES
     ======================================================= */

  const tableauFiltre =
    useMemo(() => {
      return tableau.filter(
        (ligne) => {
          const okTrigramme =
            !filtreTrigramme ||
            ligne.trigramme ===
              filtreTrigramme;

          const cleSemaine =
            `${ligne.semaine}-${ligne.annee}`;

          const okSemaine =
            !filtreSemaine ||
            cleSemaine ===
              filtreSemaine;

          return (
            okTrigramme &&
            okSemaine
          );
        }
      );
    }, [
      tableau,
      filtreTrigramme,
      filtreSemaine,
    ]);

  /* =======================================================
     TRI
     ======================================================= */

  const tableauTrie =
    useMemo(() => {
      const copie = [
        ...tableauFiltre,
      ];

      copie.sort((a, b) => {
        let valeurA:
          | number
          | string;

        let valeurB:
          | number
          | string;

        if (
          triColonne ===
          "semaine"
        ) {
          valeurA =
            a.annee * 100 +
            a.semaine;

          valeurB =
            b.annee * 100 +
            b.semaine;
        } else if (
          triColonne ===
          "trigramme"
        ) {
          valeurA =
            a.trigramme;

          valeurB =
            b.trigramme;
        } else if (
          triColonne ===
          "total"
        ) {
          valeurA = a.total;
          valeurB = b.total;
        } else {
          valeurA =
            a.codes[
              triColonne
            ] ?? 0;

          valeurB =
            b.codes[
              triColonne
            ] ?? 0;
        }

        if (
          typeof valeurA ===
          "string"
        ) {
          const comparaison =
            valeurA.localeCompare(
              String(valeurB)
            );

          return triDirection ===
            "asc"
            ? comparaison
            : -comparaison;
        }

        return triDirection ===
          "asc"
          ? Number(valeurA) -
              Number(valeurB)
          : Number(valeurB) -
              Number(valeurA);
      });

      return copie;
    }, [
      tableauFiltre,
      triColonne,
      triDirection,
    ]);

  /* =======================================================
     TRI COLONNES
     ======================================================= */

  function changerTri(
    colonne:
      | "semaine"
      | "trigramme"
      | "total"
      | string
  ) {
    if (
      triColonne === colonne
    ) {
      setTriDirection(
        (ancienne) =>
          ancienne === "asc"
            ? "desc"
            : "asc"
      );
    } else {
      setTriColonne(colonne);
      setTriDirection("asc");
    }
  }

  function symboleTri(
    colonne:
      | "semaine"
      | "trigramme"
      | "total"
      | string
  ) {
    if (
      triColonne !== colonne
    ) {
      return "↕";
    }

    return triDirection ===
      "asc"
      ? "▲"
      : "▼";
  }

  /* =======================================================
     TOTAUX
     ======================================================= */

  function totalCode(
    code: string
  ) {
    return tableauFiltre.reduce(
      (total, ligne) =>
        total +
        (ligne.codes[code] ??
          0),
      0
    );
  }

  const totalHeuresFiltre =
    useMemo(() => {
      return tableauFiltre.reduce(
        (total, ligne) =>
          total + ligne.total,
        0
      );
    }, [tableauFiltre]);

  /* =======================================================
     AFFICHAGE
     ======================================================= */

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#f5f5f5",
        fontFamily:
          "Calibri, Arial, sans-serif",
      }}
    >
      {/* ================= HEADER ================= */}

      <header
        style={{
          background: "#c00000",
          color: "white",
          padding:
            "25px 35px",
        }}
      >
        <button
          onClick={() =>
            router.push(
              "/dashboard"
            )
          }
          style={{
            background:
              "rgba(255,255,255,0.15)",
            border:
              "1px solid rgba(255,255,255,0.3)",
            color: "white",
            borderRadius: 8,
            padding:
              "8px 14px",
            cursor: "pointer",
            marginBottom: 15,
            fontFamily:
              "inherit",
            fontWeight: 700,
          }}
        >
          🏠 Retour au tableau de bord
        </button>

        <div
          style={{
            fontSize: 32,
            fontWeight: 800,
          }}
        >
          POLYNOV
        </div>

        <div
          style={{
            marginTop: 5,
            opacity: 0.9,
          }}
        >
          Bilan d'affaires
        </div>
      </header>

      {/* ================= CONTENU ================= */}

      <div
        style={{
          maxWidth: 1400,
          margin: "0 auto",
          padding: 30,
        }}
      >
        {/* ================= RECHERCHE ================= */}

        <div
          style={{
            background:
              "white",
            borderRadius: 12,
            padding: 24,
            marginBottom: 25,
            borderLeft:
              "5px solid #c00000",
            boxShadow:
              "0 2px 8px rgba(0,0,0,0.08)",
          }}
        >
          <h1
            style={{
              margin:
                "0 0 20px 0",
              fontSize: 28,
              color: "#222",
            }}
          >
            Recherche affaire
          </h1>

          <div
            style={{
              display: "flex",
              gap: 12,
              alignItems:
                "center",
              flexWrap: "wrap",
            }}
          >
            <select
              value={
                typeAffaire
              }
              onChange={(e) =>
                setTypeAffaire(
                  e.target.value
                )
              }
              style={
                styleInput
              }
            >
              <option value="CBE">
                CBE
              </option>

              <option value="DBE">
                DBE
              </option>
            </select>

            <input
              value={numero}
              onChange={(e) =>
                setNumero(
                  e.target.value
                )
              }
              onKeyDown={(e) => {
                if (
                  e.key ===
                  "Enter"
                ) {
                  rechercher();
                }
              }}
              placeholder="1449"
              style={{
                ...styleInput,
                width: 150,
              }}
            />

            <button
              onClick={
                rechercher
              }
              disabled={
                chargement
              }
              style={{
                ...styleButtonRed,
                opacity:
                  chargement
                    ? 0.6
                    : 1,
              }}
            >
              {chargement
                ? "⏳ Recherche..."
                : "🔍 Rechercher"}
            </button>
          </div>

          {message && (
            <div
              style={{
                marginTop: 20,
                padding: 15,
                background:
                  "#f7f7f7",
                borderRadius: 8,
                borderLeft:
                  "5px solid #c00000",
                fontWeight: 700,
                color: "#333",
              }}
            >
              {message}
            </div>
          )}
        </div>

        {/* ================= STATISTIQUES ================= */}

        {lignes.length > 0 && (
          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(auto-fit, minmax(220px, 1fr))",
              gap: 20,
              marginBottom: 25,
            }}
          >
            <CarteStat
              titre="Total des heures"
              valeur={`${totalHeures.toFixed(
                2
              )} h`}
            />

            <CarteStat
              titre="Collaborateurs"
              valeur={
                collaborateurs.length
              }
            />

            <CarteStat
              titre="Semaines"
              valeur={
                semaines.length
              }
            />
          </div>
        )}

        {/* ================= FILTRES ================= */}

        {lignes.length > 0 && (
          <div
            style={{
              background:
                "white",
              borderRadius: 12,
              padding: 20,
              marginBottom: 20,
              boxShadow:
                "0 2px 8px rgba(0,0,0,0.08)",
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems:
                  "center",
                gap: 12,
                flexWrap:
                  "wrap",
              }}
            >
              <strong
                style={{
                  color: "#333",
                }}
              >
                Filtrer :
              </strong>

              <select
                value={
                  filtreTrigramme
                }
                onChange={(e) =>
                  setFiltreTrigramme(
                    e.target.value
                  )
                }
                style={
                  styleFilter
                }
              >
                <option value="">
                  Tous les collaborateurs
                </option>

                {collaborateurs.map(
                  (
                    trigramme
                  ) => (
                    <option
                      key={
                        trigramme
                      }
                      value={
                        trigramme
                      }
                    >
                      {
                        trigramme
                      }
                    </option>
                  )
                )}
              </select>

              <select
                value={
                  filtreSemaine
                }
                onChange={(e) =>
                  setFiltreSemaine(
                    e.target.value
                  )
                }
                style={
                  styleFilter
                }
              >
                <option value="">
                  Toutes les semaines
                </option>

                {semaines.map(
                  (
                    semaine
                  ) => {
                    const [
                      semaineNumero,
                      annee,
                    ] =
                      semaine.split(
                        "-"
                      );

                    return (
                      <option
                        key={
                          semaine
                        }
                        value={
                          semaine
                        }
                      >
                        S
                        {
                          semaineNumero
                        }
                        -
                        {annee}
                      </option>
                    );
                  }
                )}
              </select>

              {(filtreTrigramme ||
                filtreSemaine) && (
                <button
                  onClick={() => {
                    setFiltreTrigramme(
                      ""
                    );
                    setFiltreSemaine(
                      ""
                    );
                  }}
                  style={{
                    background:
                      "#eee",
                    border:
                      "none",
                    borderRadius: 7,
                    padding:
                      "9px 14px",
                    cursor:
                      "pointer",
                    fontFamily:
                      "inherit",
                    fontWeight:
                      700,
                  }}
                >
                  ✕ Réinitialiser
                </button>
              )}
            </div>
          </div>
        )}

        {/* ================= TABLEAU ================= */}

        {lignes.length > 0 && (
          <div
            style={{
              background:
                "white",
              borderRadius: 12,
              padding: 24,
              boxShadow:
                "0 2px 8px rgba(0,0,0,0.08)",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent:
                  "space-between",
                alignItems:
                  "center",
                gap: 15,
                flexWrap:
                  "wrap",
                marginBottom: 20,
              }}
            >
              <h2
                style={{
                  margin: 0,
                  fontSize: 22,
                  color: "#222",
                }}
              >
                Imputations
              </h2>

              <div
                style={{
                  fontSize: 14,
                  color: "#666",
                  fontWeight: 700,
                }}
              >
                {
                  tableauFiltre.length
                }{" "}
                ligne
                {tableauFiltre.length >
                1
                  ? "s"
                  : ""}{" "}
                •{" "}
                {totalHeuresFiltre.toFixed(
                  2
                )}{" "}
                h
              </div>
            </div>

            <div
              style={{
                overflowX:
                  "auto",
                border:
                  "1px solid #eeeeee",
                borderRadius: 8,
              }}
            >
              <table
                style={{
                  width:
                    "100%",
                  borderCollapse:
                    "collapse",
                  fontSize: 14,
                }}
              >
                <thead>
                  <tr
                    style={{
                      background:
                        "#f5f5f5",
                      borderBottom:
                        "2px solid #c00000",
                    }}
                  >
                    <th
                      onClick={() =>
                        changerTri(
                          "semaine"
                        )
                      }
                      style={{
                        ...styleTh,
                        cursor:
                          "pointer",
                      }}
                    >
                      Semaine{" "}
                      <span>
                        {symboleTri(
                          "semaine"
                        )}
                      </span>
                    </th>

                    <th
                      onClick={() =>
                        changerTri(
                          "trigramme"
                        )
                      }
                      style={{
                        ...styleTh,
                        cursor:
                          "pointer",
                      }}
                    >
                      Trigramme{" "}
                      <span>
                        {symboleTri(
                          "trigramme"
                        )}
                      </span>
                    </th>

                    {codes.map(
                      (code) => (
                        <th
                          key={
                            code
                          }
                          onClick={() =>
                            changerTri(
                              code
                            )
                          }
                          style={{
                            ...styleTh,
                            textAlign:
                              "right",
                            cursor:
                              "pointer",
                            color:
                              "#c00000",
                          }}
                        >
                          {
                            code
                          }{" "}
                          <span
                            style={{
                              color:
                                "#999",
                            }}
                          >
                            {symboleTri(
                              code
                            )}
                          </span>
                        </th>
                      )
                    )}

                    <th
                      onClick={() =>
                        changerTri(
                          "total"
                        )
                      }
                      style={{
                        ...styleTh,
                        textAlign:
                          "right",
                        cursor:
                          "pointer",
                        borderLeft:
                          "2px solid #ddd",
                      }}
                    >
                      Total{" "}
                      <span>
                        {symboleTri(
                          "total"
                        )}
                      </span>
                    </th>
                  </tr>
                </thead>

                <tbody>
                  {tableauTrie.map(
                    (
                      ligne,
                      index
                    ) => (
                      <tr
                        key={`${ligne.annee}-${ligne.semaine}-${ligne.trigramme}-${index}`}
                        style={{
                          borderBottom:
                            "1px solid #eeeeee",
                        }}
                      >
                        <td
                          style={{
                            ...styleTd,
                            fontWeight:
                              700,
                          }}
                        >
                          S
                          {
                            ligne.semaine
                          }
                          -
                          {
                            ligne.annee
                          }
                        </td>

                        <td
                          style={{
                            ...styleTd,
                            fontWeight:
                              700,
                            color:
                              "#c00000",
                          }}
                        >
                          {
                            ligne.trigramme
                          }
                        </td>

                        {codes.map(
                          (
                            code
                          ) => {
                            const heures =
                              ligne
                                .codes[
                                code
                              ] ??
                              0;

                            return (
                              <td
                                key={
                                  code
                                }
                                style={{
                                  ...styleTd,
                                  textAlign:
                                    "right",
                                  color:
                                    heures >
                                    0
                                      ? "#333"
                                      : "#ccc",
                                }}
                              >
                                {heures >
                                0
                                  ? heures.toFixed(
                                      2
                                    )
                                  : "–"}
                              </td>
                            );
                          }
                        )}

                        <td
                          style={{
                            ...styleTd,
                            textAlign:
                              "right",
                            fontWeight:
                              800,
                            borderLeft:
                              "2px solid #ddd",
                          }}
                        >
                          {
                            ligne.total.toFixed(
                              2
                            )
                          }{" "}
                          h
                        </td>
                      </tr>
                    )
                  )}
                </tbody>

                <tfoot>
                  <tr
                    style={{
                      background:
                        "#f7f7f7",
                      borderTop:
                        "2px solid #c00000",
                    }}
                  >
                    <td
                      colSpan={2}
                      style={{
                        ...styleTd,
                        fontWeight:
                          800,
                      }}
                    >
                      TOTAL
                    </td>

                    {codes.map(
                      (
                        code
                      ) => (
                        <td
                          key={
                            code
                          }
                          style={{
                            ...styleTd,
                            textAlign:
                              "right",
                            fontWeight:
                              800,
                            color:
                              "#c00000",
                          }}
                        >
                          {totalCode(
                            code
                          ).toFixed(
                            2
                          )}
                        </td>
                      )
                    )}

                    <td
                      style={{
                        ...styleTd,
                        textAlign:
                          "right",
                        fontWeight:
                          800,
                        borderLeft:
                          "2px solid #ddd",
                        color:
                          "#c00000",
                      }}
                    >
                      {totalHeuresFiltre.toFixed(
                        2
                      )}{" "}
                      h
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>

            <div
              style={{
                marginTop: 15,
                color: "#777",
                fontSize: 13,
              }}
            >
              Cliquez sur un en-tête de
              colonne pour trier le tableau.
            </div>
          </div>
        )}
      </div>
    </main>
  );
}

/* ========================================================= */
/* ===================== COMPOSANTS ======================== */
/* ========================================================= */

function CarteStat({
  titre,
  valeur,
}: {
  titre: string;
  valeur: string | number;
}) {
  return (
    <div
      style={{
        background:
          "white",
        borderRadius: 12,
        padding: 22,
        borderLeft:
          "5px solid #c00000",
        boxShadow:
          "0 2px 8px rgba(0,0,0,0.08)",
      }}
    >
      <div
        style={{
          color: "#666",
          fontSize: 14,
          marginBottom: 7,
        }}
      >
        {titre}
      </div>

      <div
        style={{
          color: "#c00000",
          fontSize: 30,
          fontWeight: 800,
        }}
      >
        {valeur}
      </div>
    </div>
  );
}

/* ========================================================= */
/* ======================== STYLES ========================= */
/* ========================================================= */

const styleInput = {
  height: 42,
  padding: "0 12px",
  borderRadius: 7,
  border: "1px solid #ddd",
  background: "white",
  fontFamily:
    "Calibri, Arial, sans-serif",
  fontSize: 15,
};

const styleFilter = {
  height: 38,
  padding: "0 12px",
  borderRadius: 7,
  border: "1px solid #ddd",
  background: "white",
  fontFamily:
    "Calibri, Arial, sans-serif",
  fontSize: 14,
  cursor: "pointer",
};

const styleButtonRed = {
  height: 42,
  background: "#c00000",
  color: "white",
  border: "none",
  borderRadius: 7,
  padding: "0 18px",
  cursor: "pointer",
  fontFamily:
    "Calibri, Arial, sans-serif",
  fontSize: 15,
  fontWeight: 700,
};

const styleTh = {
  padding: "12px 14px",
  textAlign: "left" as const,
  fontWeight: 700,
  color: "#333",
  whiteSpace:
    "nowrap" as const,
};

const styleTd = {
  padding: "11px 14px",
  color: "#444",
  whiteSpace:
    "nowrap" as const,
};