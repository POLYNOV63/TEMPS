"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { useRouter } from "next/navigation";

export default function DashboardPage() {
  const router = useRouter();

  const [prenom, setPrenom] = useState("");
  const [role, setRole] = useState("");
  const [chargement, setChargement] = useState(true);

  useEffect(() => {
    async function chargerCollaborateurConnecte() {
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        router.push("/login");
        return;
      }

      const { data: collaborateur, error } = await supabase
        .from("collaborateurs")
        .select("*")
        .eq("auth_user_id", user.id)
        .single();

      if (error || !collaborateur) {
        console.error("Erreur collaborateur connecté :", error);

        alert(
          "Impossible de récupérer les informations du collaborateur."
        );

        setChargement(false);
        return;
      }

      setPrenom(collaborateur.prenom ?? "");
      setRole(collaborateur.role ?? "");
      setChargement(false);
    }

    chargerCollaborateurConnecte();
  }, [router]);

  if (chargement) {
    return (
      <main
        style={{
          minHeight: "100vh",
          background: "#f5f5f5",
          fontFamily: "Calibri, Arial, sans-serif",
        }}
      >
        <header
          style={{
            background: "#c00000",
            color: "white",
            padding: "25px 35px",
          }}
        >
          <div
            style={{
              fontSize: 32,
              fontWeight: 800,
              letterSpacing: "-0.5px",
            }}
          >
            POLYNOV
          </div>

          <div
            style={{
              marginTop: 5,
              opacity: 0.9,
            }}
          >
            Tableau de bord
          </div>
        </header>

        <div
          style={{
            maxWidth: 1200,
            margin: "0 auto",
            padding: 30,
            color: "#666",
          }}
        >
          Chargement...
        </div>
      </main>
    );
  }

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#f5f5f5",
        fontFamily: "Calibri, Arial, sans-serif",
      }}
    >
      <header
        style={{
          background: "#c00000",
          color: "white",
          padding: "28px 35px 32px 35px",
          boxShadow: "0 2px 10px rgba(0,0,0,0.12)",
        }}
      >
        <div
          style={{
            maxWidth: 1200,
            margin: "0 auto",
          }}
        >
          <div
            style={{
              fontSize: 34,
              fontWeight: 800,
              letterSpacing: "-0.5px",
            }}
          >
            POLYNOV
          </div>

          <div
            style={{
              marginTop: 4,
              fontSize: 16,
              opacity: 0.9,
            }}
          >
            Gestion des temps & activités
          </div>
        </div>
      </header>

      <div
        style={{
          maxWidth: 1200,
          margin: "0 auto",
          padding: "30px 30px 50px 30px",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            gap: 20,
            flexWrap: "wrap",
            marginBottom: 30,
          }}
        >
          <div>
            <h1
              style={{
                margin: 0,
                fontSize: 34,
                color: "#222",
                fontWeight: 800,
              }}
            >
              Bonjour {prenom || "à vous"} 👋
            </h1>

            <p
              style={{
                margin: "8px 0 0 0",
                color: "#666",
                fontSize: 16,
              }}
            >
              Bienvenue dans votre espace de gestion du temps.
            </p>
          </div>

          {role && (
            <div
              style={{
                background: "white",
                borderRadius: 10,
                padding: "10px 16px",
                border: "1px solid #e5e5e5",
                boxShadow: "0 2px 6px rgba(0,0,0,0.05)",
                color: "#c00000",
                fontWeight: 700,
                fontSize: 14,
              }}
            >
              {role}
            </div>
          )}
        </div>

        <div
          style={{
            background: "white",
            borderRadius: 12,
            padding: "22px 24px",
            marginBottom: 35,
            borderLeft: "5px solid #c00000",
            boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
          }}
        >
          <div
            style={{
              fontSize: 18,
              fontWeight: 700,
              color: "#222",
              marginBottom: 6,
            }}
          >
            Gestion des temps et activités
          </div>

          <div
            style={{
              color: "#666",
              fontSize: 15,
              lineHeight: 1.5,
            }}
          >
            Saisissez vos heures, consultez vos feuilles et retrouvez
            les informations liées aux affaires POLYNOV.
          </div>
        </div>

        <SectionTitre
          titre="Mon espace"
          description="Gérer votre activité et consulter vos feuilles de temps"
        />

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
            gap: 20,
            marginBottom: 40,
          }}
        >
          <Carte
            icone="📅"
            titre="Ma semaine"
            description="Saisir et consulter votre feuille hebdomadaire"
            onClick={() => router.push("/ma-semaine")}
          />

          <Carte
            icone="🗂️"
            titre="Mes feuilles"
            description="Retrouver l'historique de vos feuilles de temps"
            onClick={() => router.push("/mes-feuilles")}
          />

          <Carte
            icone="📊"
            titre="Bilan affaire"
            description="Consulter les historiques et imputations par affaire"
            onClick={() => router.push("/affaires/bilan")}
          />
        </div>

        {role === "ADMIN" && (
          <>
            <SectionTitre
              titre="Administration"
              description="Paramétrage et suivi des collaborateurs"
            />

            <div
              style={{
                display: "grid",
                gridTemplateColumns:
                  "repeat(auto-fit, minmax(260px, 1fr))",
                gap: 20,
              }}
            >
              <Carte
                icone="👥"
                titre="Collaborateurs"
                description="Créer, modifier et gérer les collaborateurs"
                onClick={() =>
                  router.push("/admin/collaborateurs")
                }
              />

              <Carte
                icone="⏰"
                titre="Profils horaires"
                description="Gérer les profils, rythmes et bases horaires"
                onClick={() =>
                  router.push("/admin/profils-horaires")
                }
              />

              <Carte
                icone="📄"
                titre="Feuilles collaborateurs"
                description="Consulter les feuilles de temps de tous les collaborateurs"
                onClick={() =>
                  router.push("/admin/feuilles")
                }
              />

              <Carte
                icone="📈"
                titre="Bilans par personne"
                description="Analyser les heures, activités et imputations de chaque collaborateur"
                onClick={() =>
                  router.push("/admin/bilans")
                }
              />

              <Carte
                icone="📥"
                titre="Import historique"
                description="Importer les anciennes imputations depuis un fichier"
                onClick={() =>
                  router.push("/admin/import-historique")
                }
              />
            </div>
          </>
        )}
      </div>
    </main>
  );
}

function SectionTitre({
  titre,
  description,
}: {
  titre: string;
  description: string;
}) {
  return (
    <div style={{ marginBottom: 18 }}>
      <h2
        style={{
          margin: 0,
          fontSize: 23,
          color: "#222",
          fontWeight: 800,
        }}
      >
        {titre}
      </h2>

      <p
        style={{
          margin: "4px 0 0 0",
          color: "#777",
          fontSize: 14,
        }}
      >
        {description}
      </p>
    </div>
  );
}

function Carte({
  icone,
  titre,
  description,
  onClick,
}: {
  icone: string;
  titre: string;
  description: string;
  onClick: () => void;
}) {
  const [survol, setSurvol] = useState(false);

  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setSurvol(true)}
      onMouseLeave={() => setSurvol(false)}
      style={{
        background: "white",
        borderRadius: 12,
        padding: 24,
        cursor: "pointer",
        border: survol
          ? "1px solid #c00000"
          : "1px solid #eeeeee",
        borderLeft: "5px solid #c00000",
        boxShadow: survol
          ? "0 6px 16px rgba(0,0,0,0.12)"
          : "0 2px 8px rgba(0,0,0,0.08)",
        transform: survol
          ? "translateY(-2px)"
          : "translateY(0)",
        transition: "all 0.15s ease",
        minHeight: 150,
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
      }}
    >
      <div>
        <div
          style={{
            width: 46,
            height: 46,
            borderRadius: 10,
            background: "#f8e8e8",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 24,
            marginBottom: 16,
          }}
        >
          {icone}
        </div>

        <h3
          style={{
            margin: 0,
            color: "#222",
            fontSize: 20,
            fontWeight: 800,
          }}
        >
          {titre}
        </h3>

        <p
          style={{
            margin: "8px 0 0 0",
            color: "#666",
            fontSize: 14,
            lineHeight: 1.5,
          }}
        >
          {description}
        </p>
      </div>

      <div
        style={{
          marginTop: 18,
          color: "#c00000",
          fontSize: 13,
          fontWeight: 700,
          opacity: survol ? 1 : 0.8,
        }}
      >
        Ouvrir →
      </div>
    </div>
  );
}