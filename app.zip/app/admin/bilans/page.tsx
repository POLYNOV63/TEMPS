"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";

type Collaborateur = {
  id: string;
  trigramme: string;
  prenom: string;
  nom: string;
  email: string;
  actif: boolean;
  role?: string;
};

type Feuille = {
  id: string;
  collaborateur_id: string;
  semaine_debut: string;
  total_heures: number;
  total_theorique: number;
  heures_supplementaires: number;
  total_re: number;
  compteur_avant: number;
  compteur_apres: number;
  statut: string;
  updated_at: string;
};

type Jour = {
  id: string;
  feuille_id: string;
  date_jour: string;
  presence: "PRESENTIEL" | "TELETRAVAIL" | "ABSENT";
  absence: string | null;
  duree_rtt: string | null;
  heures_re: number | null;
  ticket_restaurant: boolean;
  total_heures: number;
};

type Imputation = {
  id: string;
  jour_id: string;
  type_affaire: "CBE" | "DBE" | "Divers";
  numero_affaire: string | null;
  description: string | null;
  code: string | null;
  heures: number;
};

type LigneAffaire = {
  cle: string;
  typeAffaire: string;
  numeroAffaire: string;
  description: string;
  heures: number;
};

type LigneCode = {
  code: string;
  heures: number;
};

function formatHeures(value: number | null | undefined) {
  const n = Number(value ?? 0);

  if (!Number.isFinite(n)) {
    return "0h00";
  }

  const signe = n < 0 ? "-" : "";
  const valeur = Math.abs(n);

  const heures = Math.floor(valeur);
  const minutes = Math.round((valeur - heures) * 60);

  if (minutes === 60) {
    return `${signe}${heures + 1}h00`;
  }

  return `${signe}${heures}h${minutes
    .toString()
    .padStart(2, "0")}`;
}

function formatDate(date: string) {
  if (!date) return "";

  const d = new Date(`${date}T00:00:00`);

  if (Number.isNaN(d.getTime())) {
    return date;
  }

  return d.toLocaleDateString("fr-FR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
}

function formatSemaine(date: string) {
  if (!date) return "";

  const d = new Date(`${date}T00:00:00`);

  if (Number.isNaN(d.getTime())) {
    return date;
  }

  return d.toLocaleDateString("fr-FR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
}

function pourcentage(
  heures: number,
  theorique: number
) {
  if (!theorique) return 0;

  return Math.round((heures / theorique) * 100);
}

export default function BilansPage() {
  const router = useRouter();

  const [chargement, setChargement] = useState(true);
  const [chargementBilan, setChargementBilan] = useState(false);

  const [collaborateurs, setCollaborateurs] = useState<
    Collaborateur[]
  >([]);

  const [collaborateurId, setCollaborateurId] =
    useState("");

  const [annee, setAnnee] = useState("TOUTES");

  const [feuilles, setFeuilles] = useState<Feuille[]>([]);
  const [jours, setJours] = useState<Jour[]>([]);
  const [imputations, setImputations] = useState<Imputation[]>(
    []
  );

  const [recherche, setRecherche] = useState("");
  const [onglet, setOnglet] = useState<
    "synthese" | "affaires" | "codes" | "semaines"
  >("synthese");

  useEffect(() => {
    async function initialiser() {
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        router.push("/login");
        return;
      }

      const { data: collaborateurConnecte, error } =
        await supabase
          .from("collaborateurs")
          .select("id, role")
          .eq("auth_user_id", user.id)
          .single();

      if (
        error ||
        !collaborateurConnecte ||
        collaborateurConnecte.role !== "ADMIN"
      ) {
        router.push("/dashboard");
        return;
      }

      const { data, error: erreurCollaborateurs } =
        await supabase
          .from("collaborateurs")
          .select(
            "id, trigramme, prenom, nom, email, actif, role"
          )
          .order("nom", { ascending: true });

      if (erreurCollaborateurs) {
        console.error(
          "Erreur chargement collaborateurs :",
          erreurCollaborateurs
        );
      } else {
        setCollaborateurs(data ?? []);
      }

      setChargement(false);
    }

    initialiser();
  }, [router]);

  useEffect(() => {
    if (!collaborateurId) {
      setFeuilles([]);
      setJours([]);
      setImputations([]);
      return;
    }

    async function chargerBilan() {
      setChargementBilan(true);

      let requete = supabase
        .from("feuilles_heures")
        .select(
          "id, collaborateur_id, semaine_debut, total_heures, total_theorique, heures_supplementaires, total_re, compteur_avant, compteur_apres, statut, updated_at"
        )
        .eq("collaborateur_id", collaborateurId)
        .order("semaine_debut", {
          ascending: false,
        });

      if (annee !== "TOUTES") {
        requete = requete
          .gte("semaine_debut", `${annee}-01-01`)
          .lt(
            "semaine_debut",
            `${Number(annee) + 1}-01-01`
          );
      }

      const { data: feuillesData, error: erreurFeuilles } =
        await requete;

      if (erreurFeuilles) {
        console.error(
          "Erreur chargement feuilles :",
          erreurFeuilles
        );

        setFeuilles([]);
        setJours([]);
        setImputations([]);
        setChargementBilan(false);
        return;
      }

      const feuillesChargees = (feuillesData ??
        []) as Feuille[];

      setFeuilles(feuillesChargees);

      const feuilleIds = feuillesChargees.map(
        (f) => f.id
      );

      if (feuilleIds.length === 0) {
        setJours([]);
        setImputations([]);
        setChargementBilan(false);
        return;
      }

      const { data: joursData, error: erreurJours } =
        await supabase
          .from("feuilles_heures_jours")
          .select(
            "id, feuille_id, date_jour, presence, absence, duree_rtt, heures_re, ticket_restaurant, total_heures"
          )
          .in("feuille_id", feuilleIds)
          .order("date_jour", {
            ascending: true,
          });

      if (erreurJours) {
        console.error(
          "Erreur chargement jours :",
          erreurJours
        );
      }

      const joursCharges = (joursData ?? []) as Jour[];

      setJours(joursCharges);

      const jourIds = joursCharges.map((j) => j.id);

      if (jourIds.length === 0) {
        setImputations([]);
        setChargementBilan(false);
        return;
      }

      const { data: imputationsData, error: erreurImputations } =
        await supabase
          .from("feuilles_heures_imputations")
          .select(
            "id, jour_id, type_affaire, numero_affaire, description, code, heures"
          )
          .in("jour_id", jourIds);

      if (erreurImputations) {
        console.error(
          "Erreur chargement imputations :",
          erreurImputations
        );
      }

      setImputations(
        (imputationsData ?? []) as Imputation[]
      );

      setChargementBilan(false);
    }

    chargerBilan();
  }, [collaborateurId, annee]);

  const collaborateurSelectionne = useMemo(
    () =>
      collaborateurs.find(
        (c) => c.id === collaborateurId
      ),
    [collaborateurs, collaborateurId]
  );

  const anneesDisponibles = useMemo(() => {
    const annees = new Set<string>();

    for (const feuille of feuilles) {
      if (feuille.semaine_debut) {
        annees.add(feuille.semaine_debut.substring(0, 4));
      }
    }

    return Array.from(annees).sort((a, b) =>
      b.localeCompare(a)
    );
  }, [feuilles]);

  const feuillesFiltrees = useMemo(() => {
    const terme = recherche.trim().toLowerCase();

    if (!terme) {
      return feuilles;
    }

    return feuilles.filter((feuille) => {
      const texte = [
        feuille.semaine_debut,
        feuille.statut,
        feuille.total_heures,
      ]
        .join(" ")
        .toLowerCase();

      return texte.includes(terme);
    });
  }, [feuilles, recherche]);

  const totalHeures = useMemo(
    () =>
      feuilles.reduce(
        (total, feuille) =>
          total + Number(feuille.total_heures ?? 0),
        0
      ),
    [feuilles]
  );

  const totalTheorique = useMemo(
    () =>
      feuilles.reduce(
        (total, feuille) =>
          total + Number(feuille.total_theorique ?? 0),
        0
      ),
    [feuilles]
  );

  const totalHS = useMemo(
    () =>
      feuilles.reduce(
        (total, feuille) =>
          total +
          Number(feuille.heures_supplementaires ?? 0),
        0
      ),
    [feuilles]
  );

  const totalRE = useMemo(
    () =>
      feuilles.reduce(
        (total, feuille) =>
          total + Number(feuille.total_re ?? 0),
        0
      ),
    [feuilles]
  );

  const soldeGlobal = totalHeures - totalTheorique;

  const totalTickets = useMemo(
    () =>
      jours.filter(
        (jour) => jour.ticket_restaurant === true
      ).length,
    [jours]
  );

  const presenceStats = useMemo(() => {
    let presentiel = 0;
    let teletravail = 0;
    let absent = 0;

    for (const jour of jours) {
      if (jour.presence === "PRESENTIEL") {
        presentiel++;
      } else if (jour.presence === "TELETRAVAIL") {
        teletravail++;
      } else {
        absent++;
      }
    }

    return {
      presentiel,
      teletravail,
      absent,
    };
  }, [jours]);

  const absenceStats = useMemo(() => {
    const stats: Record<string, number> = {
      CP: 0,
      RE: 0,
      ML: 0,
      RTT: 0,
      FE: 0,
      AUTRE: 0,
    };

    for (const jour of jours) {
      const absence = jour.absence ?? "";

      if (absence && absence in stats) {
        stats[absence]++;
      }
    }

    return stats;
  }, [jours]);

  const affaires = useMemo<LigneAffaire[]>(() => {
    const map = new Map<string, LigneAffaire>();

    for (const imputation of imputations) {
      const typeAffaire =
        imputation.type_affaire ?? "Divers";

      const numero =
        imputation.numero_affaire ?? "";

      const description =
        imputation.description ?? "";

      const cle = [
        typeAffaire,
        numero,
        description,
      ].join("|");

      const existante = map.get(cle);

      if (existante) {
        existante.heures += Number(
          imputation.heures ?? 0
        );
      } else {
        map.set(cle, {
          cle,
          typeAffaire,
          numeroAffaire: numero,
          description,
          heures: Number(imputation.heures ?? 0),
        });
      }
    }

    return Array.from(map.values()).sort(
      (a, b) => b.heures - a.heures
    );
  }, [imputations]);

  const codes = useMemo<LigneCode[]>(() => {
    const map = new Map<string, number>();

    for (const imputation of imputations) {
      const code = imputation.code || "Sans code";

      map.set(
        code,
        (map.get(code) ?? 0) +
          Number(imputation.heures ?? 0)
      );
    }

    return Array.from(map.entries())
      .map(([code, heures]) => ({
        code,
        heures,
      }))
      .sort((a, b) => b.heures - a.heures);
  }, [imputations]);

  const heuresParType = useMemo(() => {
    const result = {
      CBE: 0,
      DBE: 0,
      Divers: 0,
    };

    for (const imputation of imputations) {
      const type = imputation.type_affaire;

      if (type === "CBE") {
        result.CBE += Number(imputation.heures ?? 0);
      } else if (type === "DBE") {
        result.DBE += Number(imputation.heures ?? 0);
      } else {
        result.Divers += Number(imputation.heures ?? 0);
      }
    }

    return result;
  }, [imputations]);

  if (chargement) {
    return (
      <main style={styles.page}>
        <Header />

        <div style={styles.container}>
          <div style={styles.loading}>
            Chargement...
          </div>
        </div>
      </main>
    );
  }

  return (
    <main style={styles.page}>
      <Header />

      <div style={styles.container}>
        <div style={styles.topBar}>
          <div>
            <button
              onClick={() => router.push("/dashboard")}
              style={styles.backButton}
            >
              ← Tableau de bord
            </button>

            <h1 style={styles.title}>
              Bilans par personne
            </h1>

            <p style={styles.subtitle}>
              Analyse détaillée de l'activité et des
              imputations des collaborateurs.
            </p>
          </div>
        </div>

        <div style={styles.selectionCard}>
          <div style={styles.selectionGrid}>
            <div>
              <label style={styles.label}>
                Collaborateur
              </label>

              <select
                value={collaborateurId}
                onChange={(e) =>
                  setCollaborateurId(e.target.value)
                }
                style={styles.select}
              >
                <option value="">
                  Sélectionner un collaborateur...
                </option>

                {collaborateurs.map((collaborateur) => (
                  <option
                    key={collaborateur.id}
                    value={collaborateur.id}
                  >
                    {collaborateur.trigramme} —{" "}
                    {collaborateur.prenom}{" "}
                    {collaborateur.nom}
                    {!collaborateur.actif
                      ? " (inactif)"
                      : ""}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label style={styles.label}>
                Année
              </label>

              <select
                value={annee}
                onChange={(e) =>
                  setAnnee(e.target.value)
                }
                style={styles.select}
                disabled={!collaborateurId}
              >
                <option value="TOUTES">
                  Toutes les années
                </option>

                {anneesDisponibles.map((a) => (
                  <option key={a} value={a}>
                    {a}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label style={styles.label}>
                Recherche
              </label>

              <input
                value={recherche}
                onChange={(e) =>
                  setRecherche(e.target.value)
                }
                placeholder="Semaine, statut..."
                style={styles.input}
                disabled={!collaborateurId}
              />
            </div>
          </div>
        </div>

        {!collaborateurId && (
          <div style={styles.emptyCard}>
            <div style={styles.emptyIcon}>
              👤
            </div>

            <div style={styles.emptyTitle}>
              Sélectionnez un collaborateur
            </div>

            <div style={styles.emptyText}>
              Choisissez une personne ci-dessus pour
              afficher son historique et le détail de
              son activité.
            </div>
          </div>
        )}

        {collaborateurId && chargementBilan && (
          <div style={styles.emptyCard}>
            <div style={styles.emptyIcon}>
              ⏳
            </div>

            <div style={styles.emptyTitle}>
              Chargement du bilan...
            </div>
          </div>
        )}

        {collaborateurId &&
          !chargementBilan &&
          collaborateurSelectionne && (
            <>
              <div style={styles.personHeader}>
                <div>
                  <div style={styles.personTrigramme}>
                    {collaborateurSelectionne.trigramme}
                  </div>

                  <div style={styles.personName}>
                    {collaborateurSelectionne.prenom}{" "}
                    {collaborateurSelectionne.nom}
                  </div>

                  <div style={styles.personEmail}>
                    {collaborateurSelectionne.email}
                  </div>
                </div>

                <div
                  style={{
                    ...styles.activeBadge,
                    backgroundColor:
                      collaborateurSelectionne.actif
                        ? "#e8f5e9"
                        : "#f3f3f3",
                    color:
                      collaborateurSelectionne.actif
                        ? "#26733a"
                        : "#777",
                  }}
                >
                  {collaborateurSelectionne.actif
                    ? "ACTIF"
                    : "INACTIF"}
                </div>
              </div>

              {feuilles.length === 0 ? (
                <div style={styles.emptyCard}>
                  <div style={styles.emptyIcon}>
                    📄
                  </div>

                  <div style={styles.emptyTitle}>
                    Aucune feuille enregistrée
                  </div>

                  <div style={styles.emptyText}>
                    Aucune feuille d'heures ne correspond
                    à ce collaborateur et à la période
                    sélectionnée.
                  </div>
                </div>
              ) : (
                <>
                  <div style={styles.kpiGrid}>
                    <Kpi
                      label="Heures saisies"
                      value={formatHeures(totalHeures)}
                      detail={`${feuilles.length} feuille${
                        feuilles.length > 1 ? "s" : ""
                      }`}
                    />

                    <Kpi
                      label="Heures théoriques"
                      value={formatHeures(
                        totalTheorique
                      )}
                      detail={`${pourcentage(
                        totalHeures,
                        totalTheorique
                      )}% réalisé`}
                    />

                    <Kpi
                      label="Heures supplémentaires"
                      value={formatHeures(totalHS)}
                      detail={
                        totalHS >= 0
                          ? "au-dessus de la base"
                          : "en dessous de la base"
                      }
                      accent={totalHS > 0}
                    />

                    <Kpi
                      label="Récupération"
                      value={formatHeures(totalRE)}
                      detail="RE enregistrées"
                    />

                    <Kpi
                      label="Solde global"
                      value={formatHeures(soldeGlobal)}
                      detail={
                        soldeGlobal >= 0
                          ? "solde positif"
                          : "heures manquantes"
                      }
                      accent={soldeGlobal > 0}
                    />

                    <Kpi
                      label="Tickets restaurant"
                      value={String(totalTickets)}
                      detail="jours concernés"
                    />
                  </div>

                  <div style={styles.tabs}>
                    <Tab
                      active={onglet === "synthese"}
                      onClick={() =>
                        setOnglet("synthese")
                      }
                    >
                      Synthèse
                    </Tab>

                    <Tab
                      active={onglet === "affaires"}
                      onClick={() =>
                        setOnglet("affaires")
                      }
                    >
                      Affaires
                    </Tab>

                    <Tab
                      active={onglet === "codes"}
                      onClick={() =>
                        setOnglet("codes")
                      }
                    >
                      Codes
                    </Tab>

                    <Tab
                      active={onglet === "semaines"}
                      onClick={() =>
                        setOnglet("semaines")
                      }
                    >
                      Semaines
                    </Tab>
                  </div>

                  {onglet === "synthese" && (
                    <Synthese
                      heuresParType={heuresParType}
                      presenceStats={presenceStats}
                      absenceStats={absenceStats}
                      feuilles={feuilles}
                    />
                  )}

                  {onglet === "affaires" && (
                    <Affaires
                      affaires={affaires}
                      totalHeures={totalHeures}
                    />
                  )}

                  {onglet === "codes" && (
                    <Codes
                      codes={codes}
                      totalImputations={imputations.reduce(
                        (total, imputation) =>
                          total +
                          Number(
                            imputation.heures ?? 0
                          ),
                        0
                      )}
                    />
                  )}

                  {onglet === "semaines" && (
                    <Semaines
                      feuilles={feuillesFiltrees}
                      collaborateurId={
                        collaborateurId
                      }
                    />
                  )}
                </>
              )}
            </>
          )}
      </div>
    </main>
  );
}

function Header() {
  return (
    <header style={styles.header}>
      <div style={styles.headerInner}>
        <div style={styles.logo}>
          POLYNOV
        </div>

        <div style={styles.headerSubtitle}>
          Gestion des temps & activités
        </div>
      </div>
    </header>
  );
}

function Kpi({
  label,
  value,
  detail,
  accent = false,
}: {
  label: string;
  value: string;
  detail: string;
  accent?: boolean;
}) {
  return (
    <div style={styles.kpi}>
      <div style={styles.kpiLabel}>
        {label}
      </div>

      <div
        style={{
          ...styles.kpiValue,
          color: accent ? "#c00000" : "#222",
        }}
      >
        {value}
      </div>

      <div style={styles.kpiDetail}>
        {detail}
      </div>
    </div>
  );
}

function Tab({
  children,
  active,
  onClick,
}: {
  children: React.ReactNode;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      style={{
        ...styles.tab,
        color: active ? "#c00000" : "#666",
        borderBottom: active
          ? "3px solid #c00000"
          : "3px solid transparent",
        fontWeight: active ? 800 : 600,
      }}
    >
      {children}
    </button>
  );
}

function Synthese({
  heuresParType,
  presenceStats,
  absenceStats,
  feuilles,
}: {
  heuresParType: {
    CBE: number;
    DBE: number;
    Divers: number;
  };
  presenceStats: {
    presentiel: number;
    teletravail: number;
    absent: number;
  };
  absenceStats: Record<string, number>;
  feuilles: Feuille[];
}) {
  const totalActivite =
    heuresParType.CBE +
    heuresParType.DBE +
    heuresParType.Divers;

  return (
    <div style={styles.sectionGrid}>
      <div style={styles.panel}>
        <PanelTitle
          title="Répartition de l'activité"
          description="Heures imputées selon le type d'activité"
        />

        <ProgressLine
          label="CBE"
          value={heuresParType.CBE}
          total={totalActivite}
        />

        <ProgressLine
          label="DBE"
          value={heuresParType.DBE}
          total={totalActivite}
        />

        <ProgressLine
          label="Divers"
          value={heuresParType.Divers}
          total={totalActivite}
        />
      </div>

      <div style={styles.panel}>
        <PanelTitle
          title="Présence"
          description="Répartition des jours enregistrés"
        />

        <StatRow
          label="Présentiel"
          value={`${presenceStats.presentiel} jours`}
        />

        <StatRow
          label="Télétravail"
          value={`${presenceStats.teletravail} jours`}
        />

        <StatRow
          label="Absent"
          value={`${presenceStats.absent} jours`}
        />
      </div>

      <div style={styles.panel}>
        <PanelTitle
          title="Absences"
          description="Types d'absence enregistrés"
        />

        <StatRow
          label="Congés payés"
          value={`${absenceStats.CP} jours`}
        />

        <StatRow
          label="Récupération"
          value={`${absenceStats.RE} jours`}
        />

        <StatRow
          label="Maladie"
          value={`${absenceStats.ML} jours`}
        />

        <StatRow
          label="RTT"
          value={`${absenceStats.RTT} jours`}
        />

        <StatRow
          label="Férié"
          value={`${absenceStats.FE} jours`}
        />

        <StatRow
          label="Autre"
          value={`${absenceStats.AUTRE} jours`}
        />
      </div>

      <div style={styles.panel}>
        <PanelTitle
          title="Historique"
          description="État général des feuilles enregistrées"
        />

        <StatRow
          label="Feuilles enregistrées"
          value={String(feuilles.length)}
        />

        <StatRow
          label="Complètes"
          value={String(
            feuilles.filter(
              (f) =>
                Number(f.total_heures) >=
                Number(f.total_theorique)
            ).length
          )}
        />

        <StatRow
          label="Avec heures supplémentaires"
          value={String(
            feuilles.filter(
              (f) =>
                Number(
                  f.heures_supplementaires
                ) > 0
            ).length
          )}
        />
      </div>
    </div>
  );
}

function ProgressLine({
  label,
  value,
  total,
}: {
  label: string;
  value: number;
  total: number;
}) {
  const percentage =
    total > 0 ? Math.round((value / total) * 100) : 0;

  return (
    <div style={{ marginBottom: 22 }}>
      <div style={styles.progressHeader}>
        <span style={styles.progressLabel}>
          {label}
        </span>

        <span style={styles.progressValue}>
          {formatHeures(value)}{" "}
          <span style={{ color: "#999" }}>
            ({percentage}%)
          </span>
        </span>
      </div>

      <div style={styles.progressBackground}>
        <div
          style={{
            ...styles.progressBar,
            width: `${Math.min(100, percentage)}%`,
          }}
        />
      </div>
    </div>
  );
}

function StatRow({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div style={styles.statRow}>
      <span>{label}</span>

      <strong>{value}</strong>
    </div>
  );
}

function PanelTitle({
  title,
  description,
}: {
  title: string;
  description: string;
}) {
  return (
    <div style={{ marginBottom: 24 }}>
      <h3 style={styles.panelTitle}>
        {title}
      </h3>

      <p style={styles.panelDescription}>
        {description}
      </p>
    </div>
  );
}

function Affaires({
  affaires,
  totalHeures,
}: {
  affaires: LigneAffaire[];
  totalHeures: number;
}) {
  return (
    <div style={styles.panel}>
      <PanelTitle
        title="Heures par affaire"
        description="Toutes les imputations regroupées par affaire"
      />

      {affaires.length === 0 ? (
        <div style={styles.noData}>
          Aucune imputation enregistrée.
        </div>
      ) : (
        <div style={styles.tableWrapper}>
          <table style={styles.table}>
            <thead>
              <tr>
                <th style={styles.th}>
                  Type
                </th>

                <th style={styles.th}>
                  Affaire
                </th>

                <th style={styles.th}>
                  Description
                </th>

                <th
                  style={{
                    ...styles.th,
                    textAlign: "right",
                  }}
                >
                  Heures
                </th>

                <th
                  style={{
                    ...styles.th,
                    textAlign: "right",
                  }}
                >
                  %
                </th>
              </tr>
            </thead>

            <tbody>
              {affaires.map((affaire) => {
                const pct =
                  totalHeures > 0
                    ? Math.round(
                        (affaire.heures /
                          totalHeures) *
                          100
                      )
                    : 0;

                return (
                  <tr key={affaire.cle}>
                    <td style={styles.td}>
                      <Badge
                        text={affaire.typeAffaire}
                      />
                    </td>

                    <td style={styles.tdStrong}>
                      {affaire.numeroAffaire ||
                        "—"}
                    </td>

                    <td style={styles.td}>
                      {affaire.description ||
                        "—"}
                    </td>

                    <td
                      style={{
                        ...styles.tdStrong,
                        textAlign: "right",
                      }}
                    >
                      {formatHeures(
                        affaire.heures
                      )}
                    </td>

                    <td
                      style={{
                        ...styles.td,
                        textAlign: "right",
                      }}
                    >
                      {pct}%
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function Codes({
  codes,
  totalImputations,
}: {
  codes: LigneCode[];
  totalImputations: number;
}) {
  return (
    <div style={styles.panel}>
      <PanelTitle
        title="Heures par code"
        description="Répartition des heures selon les codes d'activité"
      />

      {codes.length === 0 ? (
        <div style={styles.noData}>
          Aucun code d'activité enregistré.
        </div>
      ) : (
        <div style={styles.codeGrid}>
          {codes.map((ligne) => {
            const pct =
              totalImputations > 0
                ? Math.round(
                    (ligne.heures /
                      totalImputations) *
                      100
                  )
                : 0;

            return (
              <div
                key={ligne.code}
                style={styles.codeCard}
              >
                <div style={styles.codeTop}>
                  <div style={styles.codeName}>
                    {ligne.code}
                  </div>

                  <div style={styles.codeHours}>
                    {formatHeures(
                      ligne.heures
                    )}
                  </div>
                </div>

                <div style={styles.progressBackground}>
                  <div
                    style={{
                      ...styles.progressBar,
                      width: `${Math.min(
                        100,
                        pct
                      )}%`,
                    }}
                  />
                </div>

                <div style={styles.codePct}>
                  {pct}% des heures imputées
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function Semaines({
  feuilles,
  collaborateurId,
}: {
  feuilles: Feuille[];
  collaborateurId: string;
}) {
  return (
    <div style={styles.panel}>
      <PanelTitle
        title="Historique hebdomadaire"
        description="Accès direct aux feuilles de chaque semaine"
      />

      {feuilles.length === 0 ? (
        <div style={styles.noData}>
          Aucune feuille correspondant à la
          recherche.
        </div>
      ) : (
        <div style={styles.tableWrapper}>
          <table style={styles.table}>
            <thead>
              <tr>
                <th style={styles.th}>
                  Semaine
                </th>

                <th
                  style={{
                    ...styles.th,
                    textAlign: "right",
                  }}
                >
                  Heures
                </th>

                <th
                  style={{
                    ...styles.th,
                    textAlign: "right",
                  }}
                >
                  Théorique
                </th>

                <th
                  style={{
                    ...styles.th,
                    textAlign: "right",
                  }}
                >
                  HS
                </th>

                <th style={styles.th}>
                  Statut
                </th>

                <th style={styles.th}>
                  Action
                </th>
              </tr>
            </thead>

            <tbody>
              {feuilles.map((feuille) => {
                const complete =
                  Number(feuille.total_heures) >=
                  Number(
                    feuille.total_theorique
                  );

                return (
                  <tr key={feuille.id}>
                    <td style={styles.tdStrong}>
                      Semaine du{" "}
                      {formatSemaine(
                        feuille.semaine_debut
                      )}
                    </td>

                    <td
                      style={{
                        ...styles.tdStrong,
                        textAlign: "right",
                      }}
                    >
                      {formatHeures(
                        Number(
                          feuille.total_heures
                        )
                      )}
                    </td>

                    <td
                      style={{
                        ...styles.td,
                        textAlign: "right",
                      }}
                    >
                      {formatHeures(
                        Number(
                          feuille.total_theorique
                        )
                      )}
                    </td>

                    <td
                      style={{
                        ...styles.td,
                        textAlign: "right",
                        color:
                          Number(
                            feuille.heures_supplementaires
                          ) > 0
                            ? "#c00000"
                            : "#555",
                        fontWeight:
                          Number(
                            feuille.heures_supplementaires
                          ) > 0
                            ? 800
                            : 500,
                      }}
                    >
                      {formatHeures(
                        Number(
                          feuille.heures_supplementaires
                        )
                      )}
                    </td>

                    <td style={styles.td}>
                      <Badge
                        text={
                          complete
                            ? "Complète"
                            : "Incomplète"
                        }
                        success={complete}
                      />
                    </td>

                    <td style={styles.td}>
                      <button
                        onClick={() => {
                          window.location.href =
                            `/ma-semaine?semaine=${encodeURIComponent(
                              feuille.semaine_debut
                            )}&collaborateur=${encodeURIComponent(
                              collaborateurId
                            )}`;
                        }}
                        style={styles.openButton}
                      >
                        Ouvrir →
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function Badge({
  text,
  success,
}: {
  text: string;
  success?: boolean;
}) {
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        padding: "5px 9px",
        borderRadius: 7,
        fontSize: 12,
        fontWeight: 800,
        background:
          success === false
            ? "#fff0f0"
            : "#f8e8e8",
        color:
          success === false
            ? "#c00000"
            : "#a00000",
      }}
    >
      {text}
    </span>
  );
}

const styles: Record<string, React.CSSProperties> = {
  page: {
    minHeight: "100vh",
    background: "#f5f5f5",
    fontFamily: "Calibri, Arial, sans-serif",
  },

  header: {
    background: "#c00000",
    color: "white",
    padding: "28px 35px 32px",
    boxShadow: "0 2px 10px rgba(0,0,0,0.12)",
  },

  headerInner: {
    maxWidth: 1200,
    margin: "0 auto",
  },

  logo: {
    fontSize: 34,
    fontWeight: 800,
    letterSpacing: "-0.5px",
  },

  headerSubtitle: {
    marginTop: 4,
    fontSize: 16,
    opacity: 0.9,
  },

  container: {
    maxWidth: 1200,
    margin: "0 auto",
    padding: "30px 30px 60px",
  },

  topBar: {
    marginBottom: 25,
  },

  backButton: {
    border: "none",
    background: "transparent",
    color: "#c00000",
    fontSize: 14,
    fontWeight: 700,
    padding: 0,
    cursor: "pointer",
    marginBottom: 12,
  },

  title: {
    margin: 0,
    fontSize: 34,
    color: "#222",
    fontWeight: 800,
  },

  subtitle: {
    margin: "7px 0 0",
    color: "#666",
    fontSize: 16,
  },

  selectionCard: {
    background: "white",
    borderRadius: 12,
    padding: 22,
    marginBottom: 24,
    borderLeft: "5px solid #c00000",
    boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
  },

  selectionGrid: {
    display: "grid",
    gridTemplateColumns:
      "minmax(280px, 2fr) minmax(150px, 1fr) minmax(220px, 1.2fr)",
    gap: 18,
  },

  label: {
    display: "block",
    marginBottom: 7,
    color: "#555",
    fontSize: 13,
    fontWeight: 800,
  },

  select: {
    width: "100%",
    boxSizing: "border-box",
    padding: "11px 12px",
    borderRadius: 8,
    border: "1px solid #ddd",
    background: "white",
    color: "#222",
    fontSize: 14,
    fontFamily: "Calibri, Arial, sans-serif",
    outline: "none",
  },

  input: {
    width: "100%",
    boxSizing: "border-box",
    padding: "11px 12px",
    borderRadius: 8,
    border: "1px solid #ddd",
    background: "white",
    color: "#222",
    fontSize: 14,
    fontFamily: "Calibri, Arial, sans-serif",
    outline: "none",
  },

  personHeader: {
    background: "white",
    borderRadius: 12,
    padding: "20px 24px",
    marginBottom: 20,
    boxShadow: "0 2px 8px rgba(0,0,0,0.07)",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 20,
  },

  personTrigramme: {
    color: "#c00000",
    fontSize: 13,
    fontWeight: 900,
    letterSpacing: 1,
    marginBottom: 3,
  },

  personName: {
    color: "#222",
    fontSize: 24,
    fontWeight: 800,
  },

  personEmail: {
    color: "#777",
    fontSize: 13,
    marginTop: 3,
  },

  activeBadge: {
    padding: "7px 11px",
    borderRadius: 7,
    fontSize: 12,
    fontWeight: 900,
  },

  kpiGrid: {
    display: "grid",
    gridTemplateColumns:
      "repeat(auto-fit, minmax(175px, 1fr))",
    gap: 15,
    marginBottom: 24,
  },

  kpi: {
    background: "white",
    borderRadius: 11,
    padding: "18px 19px",
    boxShadow: "0 2px 7px rgba(0,0,0,0.07)",
    border: "1px solid #eeeeee",
  },

  kpiLabel: {
    color: "#777",
    fontSize: 13,
    fontWeight: 700,
    marginBottom: 7,
  },

  kpiValue: {
    fontSize: 27,
    fontWeight: 900,
    lineHeight: 1.1,
  },

  kpiDetail: {
    color: "#999",
    fontSize: 12,
    marginTop: 6,
  },

  tabs: {
    display: "flex",
    gap: 5,
    borderBottom: "1px solid #ddd",
    marginBottom: 20,
    overflowX: "auto",
  },

  tab: {
    background: "transparent",
    border: "none",
    padding: "12px 17px",
    cursor: "pointer",
    fontSize: 14,
    whiteSpace: "nowrap",
    fontFamily: "Calibri, Arial, sans-serif",
  },

  sectionGrid: {
    display: "grid",
    gridTemplateColumns:
      "repeat(auto-fit, minmax(320px, 1fr))",
    gap: 20,
  },

  panel: {
    background: "white",
    borderRadius: 12,
    padding: 24,
    boxShadow: "0 2px 8px rgba(0,0,0,0.07)",
    border: "1px solid #eeeeee",
  },

  panelTitle: {
    margin: 0,
    color: "#222",
    fontSize: 20,
    fontWeight: 800,
  },

  panelDescription: {
    margin: "5px 0 0",
    color: "#888",
    fontSize: 13,
  },

  progressHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 7,
    gap: 15,
  },

  progressLabel: {
    color: "#444",
    fontSize: 14,
    fontWeight: 700,
  },

  progressValue: {
    color: "#333",
    fontSize: 13,
    fontWeight: 700,
  },

  progressBackground: {
    height: 8,
    background: "#eeeeee",
    borderRadius: 20,
    overflow: "hidden",
  },

  progressBar: {
    height: "100%",
    background: "#c00000",
    borderRadius: 20,
    transition: "width 0.2s ease",
  },

  statRow: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "11px 0",
    borderBottom: "1px solid #f0f0f0",
    color: "#555",
    fontSize: 14,
  },

  tableWrapper: {
    overflowX: "auto",
  },

  table: {
    width: "100%",
    borderCollapse: "collapse",
    fontSize: 14,
  },

  th: {
    textAlign: "left",
    padding: "11px 10px",
    background: "#fafafa",
    color: "#666",
    fontSize: 12,
    fontWeight: 800,
    borderBottom: "1px solid #ddd",
    whiteSpace: "nowrap",
  },

  td: {
    padding: "13px 10px",
    color: "#555",
    borderBottom: "1px solid #eeeeee",
    verticalAlign: "middle",
  },

  tdStrong: {
    padding: "13px 10px",
    color: "#222",
    fontWeight: 700,
    borderBottom: "1px solid #eeeeee",
    verticalAlign: "middle",
  },

  openButton: {
    border: "none",
    background: "#f8e8e8",
    color: "#c00000",
    borderRadius: 7,
    padding: "7px 10px",
    fontSize: 12,
    fontWeight: 800,
    cursor: "pointer",
    whiteSpace: "nowrap",
  },

  codeGrid: {
    display: "grid",
    gridTemplateColumns:
      "repeat(auto-fit, minmax(230px, 1fr))",
    gap: 14,
  },

  codeCard: {
    border: "1px solid #eeeeee",
    borderRadius: 10,
    padding: 16,
    background: "#fcfcfc",
  },

  codeTop: {
    display: "flex",
    justifyContent: "space-between",
    gap: 10,
    alignItems: "center",
    marginBottom: 11,
  },

  codeName: {
    color: "#c00000",
    fontSize: 17,
    fontWeight: 900,
  },

  codeHours: {
    color: "#222",
    fontSize: 15,
    fontWeight: 800,
  },

  codePct: {
    marginTop: 7,
    color: "#999",
    fontSize: 11,
  },

  emptyCard: {
    background: "white",
    borderRadius: 12,
    padding: "55px 25px",
    textAlign: "center",
    boxShadow: "0 2px 8px rgba(0,0,0,0.07)",
    border: "1px solid #eeeeee",
  },

  emptyIcon: {
    fontSize: 38,
    marginBottom: 12,
  },

  emptyTitle: {
    color: "#222",
    fontSize: 20,
    fontWeight: 800,
  },

  emptyText: {
    maxWidth: 550,
    margin: "8px auto 0",
    color: "#777",
    fontSize: 14,
    lineHeight: 1.5,
  },

  loading: {
    background: "white",
    borderRadius: 12,
    padding: 30,
    color: "#666",
    boxShadow: "0 2px 8px rgba(0,0,0,0.07)",
  },

  noData: {
    padding: "35px 15px",
    textAlign: "center",
    color: "#888",
    fontSize: 14,
  },
};